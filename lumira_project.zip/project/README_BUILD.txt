APP DNA STUDIO - ANDROID SHELL EXPORT

App Name: Lumira Ai
Package: Com.lumira.ai
Entry: app/src/main/assets/www/Lumira Ai/index.html

app/src/main/assets/www/  -> imported/builder web app
app/src/main/java/...     -> MainActivity WebView

To build manually:

  cd android_shell
  ./gradlew assembleDebug   (after you install Gradle + Android SDK)
