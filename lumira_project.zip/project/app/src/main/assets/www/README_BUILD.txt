APP DNA STUDIO - ANDROID SHELL EXPORT

App Name: Lumira Ai
Package: Com.lumira.ai
Entry: Lumira Ai/index.html

Yeh actual Android wrapper project hai.
Next step:
1. Android build tools / Gradle wrapper add karo
2. APK build: assembleDebug / assembleRelease
3. AAB build: bundleRelease

Is shell ke andar tumhari web app files:
app/src/main/assets/www/

Main Activity:
app/src/main/java/Com/lumira/ai/MainActivity.kt
